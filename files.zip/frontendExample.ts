/**
 * frontendExample.ts (or .js)
 *
 * Drop this logic into your React Native or React frontend.
 * Shows how to:
 *   1. Fetch the task list from /tasks to build dynamic forms
 *   2. Call POST /estimate with params + multiple photos
 */

const API_BASE = "https://your-api.com"; // swap for your deployed URL

// ─── Types (copy these or import from a shared package) ───────────────────────

interface TaskParam {
  key: string;
  label: string;
  type: "number" | "boolean" | "select" | "multiselect" | "text";
  options?: string[];
  unit?: string;
  optional?: boolean;
  defaultValue?: string | number | boolean;
}

interface Task {
  id: string;
  label: string;
  category: string;
  params: TaskParam[];
}

interface EstimateResult {
  taskId: string;
  taskLabel: string;
  estimatedDurationMinutes: number;
  rangeMinMinutes: number;
  rangeMaxMinutes: number;
  confidenceScore: number;
  reconciledParams: Record<string, unknown>;
  notices: string[];
  breakdown: Record<string, number>;
  imageInsights?: {
    observations: string[];
    installerNotes: string[];
    additionalComplexityMinutes: number;
    inferredTaskType?: string;
  };
}

// ─── 1. Load task list (call once on app startup or task selection screen) ────

export async function fetchTaskList(): Promise<{
  tasks: Task[];
  byCategory: Record<string, { id: string; label: string }[]>;
}> {
  const res = await fetch(`${API_BASE}/tasks`);
  if (!res.ok) throw new Error("Failed to load task list");
  return res.json();
}

// ─── 2. Submit an estimate with params and any number of photos ───────────────

export async function getHandymanEstimate(
  taskId: string,
  params: Record<string, string | number | boolean | string[]>,
  photoFiles: File[]                          // File objects from <input type="file"> or camera
): Promise<EstimateResult> {

  const body = new FormData();

  // Task ID
  body.append("taskId", taskId);

  // Params as JSON
  body.append("params", JSON.stringify(params));

  // Attach all photos under the same field name "photos"
  // The backend accepts 0 to N files.
  for (const photo of photoFiles) {
    body.append("photos", photo);
  }

  const res = await fetch(`${API_BASE}/estimate`, {
    method: "POST",
    body,
    // Do NOT set Content-Type — the browser sets it automatically with the boundary for multipart
  });

  if (!res.ok) {
    const error = await res.json();
    throw new Error(error.error ?? "Estimation failed");
  }

  const data = await res.json();
  return data.result as EstimateResult;
}

// ─── 3. Usage example ────────────────────────────────────────────────────────

async function exampleUsage() {

  // Load tasks for the task-picker screen
  const { byCategory } = await fetchTaskList();
  console.log("Mounting tasks:", byCategory.mounting);
  // → [{ id: "tv_installation", label: "TV installation" }, ...]

  // --- After user selects a task and fills out the form ---

  // User picked files (from <input type="file" multiple> or camera roll)
  const photoFiles: File[] = []; // populated by your file picker

  // Example: TV installation
  const tvResult = await getHandymanEstimate(
    "tv_installation",
    {
      tvDiagonal: 65,
      mountType: "full_motion",
      wallMaterial: "drywall",
      aboveFireplace: false,
      wireConcealment: "external_track",
      outletPosition: "nearby",
    },
    photoFiles      // 0, 1, or many photos — all accepted
  );

  console.log(`⏱ Estimated: ${tvResult.estimatedDurationMinutes} min`);
  console.log(`📊 Range: ${tvResult.rangeMinMinutes}–${tvResult.rangeMaxMinutes} min`);
  console.log(`🎯 Confidence: ${(tvResult.confidenceScore * 100).toFixed(0)}%`);
  console.log(`📋 Notices:`, tvResult.notices);

  // Example: Furniture assembly
  const furnitureResult = await getHandymanEstimate(
    "furniture_assembly",
    {
      furnitureType: "wardrobe",
      itemCount: 1,
      boxCount: 4,
      hasInstructions: true,
      roomIsAccessible: true,
    },
    []   // no photos
  );

  console.log(`Wardrobe assembly: ${furnitureResult.estimatedDurationMinutes} min`);

  // Example: "Other" task with multiple photos
  const otherResult = await getHandymanEstimate(
    "other",
    {
      taskDescription: "The gutters on the front of the house are sagging and need to be re-secured.",
      estimatedComplexity: "moderate",
    },
    photoFiles   // can be multiple photos from different angles
  );

  if (otherResult.imageInsights?.inferredTaskType) {
    console.log(`AI identified task as: ${otherResult.imageInsights.inferredTaskType}`);
  }
}
